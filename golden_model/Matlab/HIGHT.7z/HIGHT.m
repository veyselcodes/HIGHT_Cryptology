%%%%
%% HIGHT : Enxample of test vectors
%%%%
clear all;

source('HIGHT_lib.m');

%%%%
%%  Example of test vectors
%%%%
%MSG='0000000000000000';
%Key='00112233445566778899aabbccddeeff';
MSG='0011223344556677';
Key='ffeeddccbbaa99887766554433221100';

%%%%
%%  chiffrement
%%%%
C=Hight_enc(MSG, Key)
%%%%
%%  Dechiffrement
%%%%
M=Hight_dec(C, Key)